import static org.junit.jupiter.api.Assertions.*;

class StocksTest {

    @org.junit.jupiter.api.Test
    void getId() {
    }

    @org.junit.jupiter.api.Test
    void setId() {
    }

    @org.junit.jupiter.api.Test
    void getValue() {
    }

    @org.junit.jupiter.api.Test
    void setValue() {
    }

    @org.junit.jupiter.api.Test
    void getQuantity() {
    }

    @org.junit.jupiter.api.Test
    void setQuantity() {
    }
}